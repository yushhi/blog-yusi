<?php if($paginator->hasPages()): ?>

    <?php if($paginator->onFirstPage()): ?>
        <span class="previous-link-disable">
            <?php echo app('translator')->get('pagination.previous'); ?>
        </span>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="previous-link">
            <?php echo app('translator')->get('pagination.previous'); ?>
        </a>
    <?php endif; ?>
    <?php if($paginator->hasMorePage()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next-link">
            <?php echo app('translator')->get('pagination.next'); ?>
        </a>
    <?php else: ?>
        <span class="next-link-disable">
            <?php echo app('translator')->get('pagination.previous'); ?>
        </span>
    <?php endif; ?>

<?php endif; ?><?php /**PATH C:\Yusi\Laravel\blog-yusi\resources\views/includes\admin\paginator.blade.php ENDPATH**/ ?>