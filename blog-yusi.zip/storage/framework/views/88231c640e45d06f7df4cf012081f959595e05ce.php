<!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <!-- <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script> -->

    <!-- jQuery JS -->
    <!-- <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script> -->

    <!-- Bootstrap JS -->
    <!-- <script src="assets/js/vendor/bootstrap.min.js"></script> -->

    <!-- Light gallery JS -->
    <!-- <script src="assets/js/plugins/lightgallery.min.js"></script> -->

    <!-- Isotope JS -->
    <!-- <script src="assets/js/plugins/isotope.min.js"></script> -->

    <!-- Masonry JS -->
    <!-- <script src="assets/js/plugins/masonry.min.js"></script> -->

    <!-- ImagesLoaded JS -->
    <!-- <script src="assets/js/plugins/images-loaded.min.js"></script> -->

    <!-- Swiper Bundle JS -->
    <!-- <script src="assets/js/plugins/swiper-bundle.min.js"></script> -->

    <!-- AOS JS -->
    <!-- <script src="assets/js/plugins/aos.js"></script> -->

    <!-- Ajax JS -->
    <!-- <script src="assets/js/plugins/ajax.mail.js"></script> -->

    <!-- Plugins JS (Please remove the comment from below plugins.min.js for better website load performance and remove plugin js files from avobe) -->
    <script src="assets/js/vendor/vendor.min.js"></script>
    <script src="assets/js/plugins/plugins.min.js"></script>


    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
<?php /**PATH C:\Yusi\Laravel\blog-yusi\resources\views/includes/user/script.blade.php ENDPATH**/ ?>