"use strict";

$("#slider1,#slider2").owlCarousel({
  items: 1,
  nav: true,
  navText: ['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>']
});
