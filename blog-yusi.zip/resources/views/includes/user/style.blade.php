<!-- Favicon -->
<link rel="icon" href="assets/images/favicon.png">

<!-- CSS
    ============================================ -->

<!-- Bootstrap CSS -->
<!-- <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">  -->

<!-- Gordita Fonts CSS -->
<link rel="stylesheet" href="assets/fonts/gordita-fonts.css" />

<!-- Icofont CSS -->
<!-- <link rel="stylesheet" href="assets/css/vendor/icofont.min.css" /> -->

<!-- Light gallery CSS -->
<!-- <link rel="stylesheet" href="assets/css/plugins/lightgallery.min.css"> -->

<!-- Swiper bundle CSS -->
<!-- <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css" /> -->

<!-- AOS CSS -->
<!-- <link rel="stylesheet" href="assets/css/plugins/aos.css"> -->


<!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from avobe) -->

<link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
<link rel="stylesheet" href="assets/css/plugins/plugins.min.css">

<!-- Main Style CSS -->
<link rel="stylesheet" href="assets/css/style.css">